


[Complie]
$ javac -cp lib/jsoup-1.8.3.jar:lib/com.springsource.org.apache.log4j-1.2.15.jar   -d output src/model/*.java src/utils/*.java src/crawler/*.java



[Run]
move the prompt to output/

$ java crawler.Main [Seed-Doc] [optional keyword]

e.g.
$ java -cp ../lib/com.springsource.org.apache.log4j-1.2.15.jar:../lib/jsoup-1.8.3.jar:../resources:.  
       crawler.Main  http://en.wikipedia.org/wiki/Hugh_of_Saint-Cher concordance
