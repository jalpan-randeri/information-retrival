[ReadMe]

[compling - Running]

1. open lucene-search-engine project into IntelliJ-IDEA,
1.1 Go to run menu and add runtime parameters as given
		location-to-cacm-folder  location-to-index-folder  queries.txt


2. Select Main class - Main.java

3. click run, 



[Description]
it will generate 4 files as output and displays results on console

1. term-frequency.txt (this file contains the term and corosponding frequency in decresing sorted order)
2. Query-Results.txt  (this file contains the results of 4 queries)
   each line is in following format
   1. rank
   2. file name
   3. score
   4. text-content atmost 200 characters

3. Zipf's Plot (normal plot)
4. Zipf's Plot (log-log plot)