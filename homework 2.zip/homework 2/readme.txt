[Read Me]
The code is executed using IntelliJ IDEA IDE. 
This submission includes the relevant project files into folder named page-rank


[Steps]
1. Open project in IntelliJ IDEA
2. From the top right corner choose run, 
   -> select Edit Run configuration,
       -> Select Main class (Main.java)
       -> Program Arguments -> path to input file (e.g. wt2g_inlinks.txt)  	
       -> Click Ok
3. click on Run button which is locted on top right corner


[Note]
Console displays the real time perplexity value of page rank algorithm. 
The output for question 1 can be obtained by uncomment the portion for question 1 
and comment out the printOutputQuestion2 and other parts which are mentioned in the code.

[output file]
Every run will generate the one file which is ranks.txt 
it has all the page and their corosponding ranks.


[Answers]
All answers are found in corrosponding folder, each question has seprate .txt file
this are located at
question 1, question 2, question 3, question 4 folder